let currentUrl = '';
let currentTitle = '';

document.addEventListener('DOMContentLoaded', async () => {
  // Independent lookups — fire both immediately instead of awaiting the tab query
  // before even starting the settings read.
  const defaultSettings = {
    aiProvider: 'anthropic',
    anthropicApiKey: '',
    anthropicModel: 'claude-3-5-haiku-20241022',
    openaiApiKey: '',
    openaiBaseUrl: 'https://api.openai.com/v1',
    openaiModel: 'gpt-4o-mini',
    openaiCustomModel: '',
    openrouterApiKey: '',
    openrouterModel: 'anthropic/claude-3.5-haiku',
    geminiApiKey: '',
    geminiModel: 'gemini-2.5-flash',
    googleCloudApiKey: '',
    googleCloudModel: 'gemini-2.5-flash',
    instapaperUsername: '',
    instapaperPassword: '',
    todoistApiToken: '',
    instapaperEnabled: false,
    todoistEnabled: false,
    thingsEnabled: false,
    readwiseEnabled: false,
    readwiseAccessToken: '',
    raindropEnabled: false,
    raindropAccessToken: '',
    instapaperCheckedByDefault: false,
    todoistCheckedByDefault: false,
    thingsCheckedByDefault: false,
    readwiseCheckedByDefault: false,
    raindropCheckedByDefault: false
  };

  const [[tab], syncData, localData] = await Promise.all([
    chrome.tabs.query({ active: true, currentWindow: true }),
    chrome.storage.sync.get(defaultSettings).catch(() => ({})),
    chrome.storage.local.get(defaultSettings).catch(() => ({}))
  ]);

  const settings = { ...defaultSettings, ...localData, ...syncData };

  if (tab) {
    currentUrl = tab.url;
    currentTitle = tab.title;
  }

  function isMacOrIOS() {
    return /Mac|iPhone|iPad|iPod/i.test(navigator.userAgent) || navigator.platform === 'MacIntel';
  }

  let provider = settings.aiProvider || 'anthropic';
  function hasProviderKey(p) {
    if (p === 'openai') {
      const isCustom = Boolean(settings.openaiBaseUrl && !settings.openaiBaseUrl.includes('api.openai.com'));
      return Boolean(settings.openaiApiKey?.trim() || isCustom);
    }
    if (p === 'openrouter') return Boolean(settings.openrouterApiKey?.trim());
    if (p === 'gemini') return Boolean(settings.geminiApiKey?.trim());
    if (p === 'google-cloud') return Boolean(settings.googleCloudApiKey?.trim());
    if (p === 'anthropic') return Boolean(settings.anthropicApiKey?.trim());
    return false;
  }

  if (!hasProviderKey(provider)) {
    const candidates = ['anthropic', 'openai', 'gemini', 'openrouter', 'google-cloud'];
    for (const cand of candidates) {
      if (hasProviderKey(cand)) {
        provider = cand;
        break;
      }
    }
  }

  let configWarning = null;
  if (!hasProviderKey(provider)) {
    configWarning = 'API key not configured. Open Settings to configure your AI Provider.';
  }

  if (configWarning) {
    showStatus(configWarning, 'warning');
    document.getElementById('analyzeBtn').disabled = true;
  }

  const autoBookmarkCb = document.getElementById('autoBookmark');
  if (!chrome.bookmarks?.create && autoBookmarkCb) {
    autoBookmarkCb.checked = false;
    autoBookmarkCb.disabled = true;
    const label = autoBookmarkCb.closest('label') || autoBookmarkCb.parentElement;
    if (label) {
      label.title = 'Bookmarks API is not supported on Firefox for Android (Mozilla Bug 1796596).';
      const smallNote = document.createElement('span');
      smallNote.style.fontSize = '11px';
      smallNote.style.color = 'var(--text-secondary)';
      smallNote.style.marginLeft = '4px';
      smallNote.textContent = '(Desktop only)';
      label.appendChild(smallNote);
    }
  }

  document.getElementById('saveToInstapaper').checked = settings.instapaperCheckedByDefault === true;
  document.getElementById('createTodoist').checked = settings.todoistCheckedByDefault === true;
  document.getElementById('createThings').checked = settings.thingsCheckedByDefault === true;
  document.getElementById('saveToReadwise').checked = settings.readwiseCheckedByDefault === true;
  document.getElementById('saveToRaindrop').checked = settings.raindropCheckedByDefault === true;

  toggleIntegrationRow('saveToInstapaperRow', 'saveToInstapaper',
    settings.instapaperEnabled === true && settings.instapaperUsername?.trim() && settings.instapaperPassword);
  toggleIntegrationRow('createTodoistRow', 'createTodoist',
    settings.todoistEnabled !== false && settings.todoistApiToken?.trim());
  toggleIntegrationRow('createThingsRow', 'createThings',
    settings.thingsEnabled !== false && isMacOrIOS());
  toggleIntegrationRow('saveToReadwiseRow', 'saveToReadwise',
    settings.readwiseEnabled && settings.readwiseAccessToken?.trim());
  toggleIntegrationRow('saveToRaindropRow', 'saveToRaindrop',
    settings.raindropEnabled && settings.raindropAccessToken?.trim());

  document.getElementById('analyzeBtn').addEventListener('click', analyzeAndBookmark);
  document.getElementById('settingsLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });



  document.getElementById('inboxLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('inbox.html') });
  });

  document.getElementById('healthCheckLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('health-check.html') });
  });
});

async function analyzeAndBookmark() {
  const analyzeBtn = document.getElementById('analyzeBtn');
  const autoBookmark = document.getElementById('autoBookmark').checked;
  const saveToInstapaper = document.getElementById('saveToInstapaper').checked;
  const createTodoist = document.getElementById('createTodoist').checked;
  const createThings = document.getElementById('createThings').checked;
  const saveToReadwise = document.getElementById('saveToReadwise').checked;
  const saveToRaindrop = document.getElementById('saveToRaindrop').checked;

  analyzeBtn.disabled = true;
  showStatus('Analyzing page...', 'loading');

  try {
    const response = await chrome.runtime.sendMessage({
      action: 'analyzeBookmark',
      url: currentUrl,
      title: currentTitle,
      saveToInstapaper: saveToInstapaper,
      createTodoist: createTodoist,
      createThings: createThings,
      autoBookmark: autoBookmark,
      saveToReadwise: saveToReadwise,
      saveToRaindrop: saveToRaindrop
    });

    if (response.success) {
      displayResults(response.data);
      if (autoBookmark && response.data.bookmarkCreated) {
        showStatus('Saved to ' + response.data.matchedCategory, 'success');
        if (response.data.chromeBookmarkId) {
          showUndoButton(response.data.chromeBookmarkId);
        }
      } else if (saveToInstapaper && response.data.isArticle && response.data.instapaper?.saved) {
        showStatus('Article saved to Instapaper', 'success');
      } else {
        showStatus('Analysis complete', 'success');
      }
    } else {
      showStatus(response.error, 'error');
    }
  } catch (error) {
    showStatus(error.message, 'error');
  } finally {
    analyzeBtn.disabled = false;
  }
}

function showStatus(message, type) {
  const container = document.getElementById('statusContainer');
  const icons = {
    loading: '<svg xmlns="http://www.w3.org/2000/svg" class="status-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 4V2A10 10 0 0 0 2 12h2a8 8 0 0 1 8-8z"/></svg>',
    success: '<svg xmlns="http://www.w3.org/2000/svg" class="status-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>',
    error: '<svg xmlns="http://www.w3.org/2000/svg" class="status-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>',
    warning: '<svg xmlns="http://www.w3.org/2000/svg" class="status-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>'
  };

  container.textContent = '';
  const statusDiv = document.createElement('div');
  statusDiv.className = `status ${type}`;

  if (icons[type]) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(icons[type], 'image/svg+xml');
    statusDiv.appendChild(doc.documentElement);
  }

  const span = document.createElement('span');
  span.textContent = message;
  statusDiv.appendChild(span);

  container.appendChild(statusDiv);
}

function displayResults(data) {
  const resultsDiv = document.getElementById('results');
  resultsDiv.classList.add('visible');

  if (data.matchedCategory && !data.isArticle) {
    document.getElementById('matchedCategory').textContent = data.matchedCategory;
    document.getElementById('matchedCategoryContainer').style.display = 'block';
  } else {
    document.getElementById('matchedCategoryContainer').style.display = 'none';
  }

  document.getElementById('resultTitle').textContent = data.title || 'N/A';
  document.getElementById('resultSummary').textContent = data.summary || 'N/A';
  document.getElementById('contentType').textContent = data.isArticle ? 'Article' : (data.contentType || 'N/A');

  if (data.categories && data.categories.length > 0) {
    const categoriesContainer = document.getElementById('categories');
    categoriesContainer.textContent = '';
    data.categories.forEach(cat => {
      const span = document.createElement('span');
      span.className = 'tag';
      span.textContent = cat;
      categoriesContainer.appendChild(span);
    });
    document.getElementById('categoriesContainer').style.display = 'block';
  } else {
    document.getElementById('categoriesContainer').style.display = 'none';
  }

  if (data.instapaper) {
    const el = document.getElementById('instapaperStatus');
    el.textContent = '';
    const dot = document.createElement('span');
    dot.className = `dot ${data.instapaper.saved ? 'success' : 'error'}`;
    el.appendChild(dot);

    if (data.instapaper.saved) {
      const link = document.createElement('a');
      link.href = 'https://www.instapaper.com/u';
      link.target = '_blank';
      link.style.color = 'inherit';
      link.textContent = 'Saved';
      el.appendChild(link);
    } else {
      el.appendChild(document.createTextNode('Not saved'));
    }
    document.getElementById('instapaperContainer').style.display = 'block';
  }

  if (data.todoist) {
    renderIntegrationStatus('todoistStatus', 'todoistContainer',
      data.todoist.created, 'Task created', data.todoist.error || 'Not created');
  }

  if (data.things) {
    renderIntegrationStatus('thingsStatus', 'thingsContainer',
      data.things.opened, 'Opened in Things', data.things.error || 'Not opened');
  }

  if (data.readwise) {
    renderIntegrationStatus('readwiseStatus', 'readwiseContainer',
      data.readwise.saved, 'Saved', data.readwise.error || 'Not saved');
  }

  if (data.raindrop) {
    renderIntegrationStatus('raindropStatus', 'raindropContainer',
      data.raindrop.saved, 'Saved', data.raindrop.error || 'Not saved');
  }
}

function toggleIntegrationRow(rowId, checkboxId, visible) {
  const row = document.getElementById(rowId);
  if (!row) return;
  row.style.display = visible ? '' : 'none';
  if (!visible) {
    const checkbox = document.getElementById(checkboxId);
    if (checkbox) checkbox.checked = false;
  }
}

function renderIntegrationStatus(statusId, containerId, success, successText, failText) {
  const el = document.getElementById(statusId);
  el.textContent = '';
  const dot = document.createElement('span');
  dot.className = `dot ${success ? 'success' : 'error'}`;
  el.appendChild(dot);
  el.appendChild(document.createTextNode(success ? successText : failText));
  document.getElementById(containerId).style.display = 'block';
}

function showUndoButton(bookmarkId) {
  const container = document.getElementById('statusContainer');
  const undoDiv = document.createElement('div');
  undoDiv.style.cssText = 'padding: 4px 12px 0; text-align: right;';

  const btn = document.createElement('button');
  btn.style.cssText = 'background: none; border: none; color: var(--accent); font-size: 12px; font-weight: 500; cursor: pointer; padding: 4px 0; font-family: inherit;';

  let secondsLeft = 7;
  const updateLabel = () => { btn.textContent = `Undo (${secondsLeft}s)`; };
  updateLabel();

  undoDiv.appendChild(btn);
  container.appendChild(undoDiv);

  const interval = setInterval(() => {
    secondsLeft--;
    if (secondsLeft <= 0) {
      clearInterval(interval);
      undoDiv.remove();
      return;
    }
    updateLabel();
  }, 1000);

  window.addEventListener('pagehide', () => clearInterval(interval), { once: true });

  btn.addEventListener('click', async () => {
    clearInterval(interval);
    undoDiv.remove();
    try {
      const response = await chrome.runtime.sendMessage({ action: 'undoBookmark', bookmarkId });
      if (response.success) {
        showStatus('Bookmark removed', 'success');
        document.getElementById('results').classList.remove('visible');
      } else {
        showStatus('Could not undo: ' + response.error, 'error');
      }
    } catch (error) {
      showStatus('Could not undo: ' + error.message, 'error');
    }
  });
}
